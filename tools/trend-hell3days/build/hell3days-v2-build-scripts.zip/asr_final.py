import json, soundfile as sf, sherpa_onnx, numpy as np
from common import START, AL, ORDER
a,sr=sf.read('heard.wav',dtype='float32'); assert sr==16000
d='models/sherpa-onnx-nemo-parakeet-tdt-0.6b-v2-int8/'
rec=sherpa_onnx.OfflineRecognizer.from_transducer(encoder=d+'encoder.int8.onnx',decoder=d+'decoder.int8.onnx',joiner=d+'joiner.int8.onnx',tokens=d+'tokens.txt',num_threads=4,model_type='nemo_transducer')
st=rec.create_stream(); st.accept_waveform(sr,a); rec.decode_stream(st)
open('heard.txt','w').write(st.result.text.strip()+'\n'); print('P1',st.result.text.strip())
w='models/sherpa-onnx-whisper-small.en/'
import glob
enc=glob.glob(w+'*encoder*int8*.onnx')[0]; dec=glob.glob(w+'*decoder*int8*.onnx')[0]; tok=glob.glob(w+'*tokens.txt')[0]
wr=sherpa_onnx.OfflineRecognizer.from_whisper(encoder=enc,decoder=dec,tokens=tok,language='en',task='transcribe',num_threads=4)
out=[]
for k in ORDER:
    s=max(0,int((START[k]-0.15)*sr)); e=min(len(a),int((START[k]+AL[k]['dur']+0.25)*sr))
    st=wr.create_stream(); st.accept_waveform(sr,a[s:e]); wr.decode_stream(st)
    t=st.result.text.strip(); out.append(t); print(k,'|',t)
open('heard2.txt','w').write(' '.join(out)+'\n')
