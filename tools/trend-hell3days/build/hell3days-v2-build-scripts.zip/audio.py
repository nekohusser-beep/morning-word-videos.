import numpy as np, soundfile as sf, math
from scipy import signal
from common import START, AL, ORDER, wt, lend, LEAD, TOTAL

SR = 48000; END = TOTAL + 0.25; N = int(SR * END)
rng = np.random.default_rng(3)
tTRI = wt('v2', 13)


def T(n): return np.arange(n) / SR


def lp(x, fc, o=2):
    b, a = signal.butter(o, fc / (SR / 2), 'low'); return signal.lfilter(b, a, x)


def hp(x, fc, o=2):
    b, a = signal.butter(o, fc / (SR / 2), 'high'); return signal.lfilter(b, a, x)


def put(bus, x, t0, g=1.0):
    i = int(t0 * SR)
    if i < 0: x = x[-i:]; i = 0
    n = min(len(x), len(bus) - i)
    if n > 0: bus[i:i + n] += x[:n] * g


def fade(x, a=0.01, r=0.05):
    na, nr = int(a * SR), int(r * SR); y = x.copy()
    if na: y[:na] *= np.linspace(0, 1, na)
    if nr: y[-nr:] *= np.linspace(1, 0, nr)
    return y


def ramp(n, t0, t1, a=0.0, b=1.0):
    """per-sample envelope: a before t0, linear to b by t1, b after"""
    tt = T(n); return np.clip((tt - t0) / max(t1 - t0, 1e-6), 0, 1) * (b - a) + a


# ---------------- voice ----------------
vo = np.zeros(N)
for k in ORDER:
    a, sr = sf.read(f'vo_{k}.wav', dtype='float32')
    a = signal.resample_poly(a, 2, 1)
    put(vo, fade(a.astype(np.float64), 0.005, 0.02), START[k])
vo = hp(vo, 75); vo *= 0.89 / np.max(np.abs(vo))
venv = lp(np.abs(vo), 7, 1); venv = np.clip(venv / 0.22, 0, 1)
duck = 1 - 0.74 * venv

# ---------------- act I: drone + heartbeat ----------------
def saw(f, n, harm=9):
    t = T(n); x = np.zeros(n)
    for h in range(1, harm + 1): x += np.sin(2 * np.pi * f * h * t + rng.uniform(0, 6.28)) / h
    return x


t = T(N)
drone = lp(saw(55.0, N) + saw(55.35, N) + 0.7 * saw(82.41, N) + 0.6 * saw(82.0, N) + 0.5 * saw(110.3, N), 420, 2)
drone *= (0.75 + 0.25 * np.sin(2 * np.pi * 0.07 * t)) / np.max(np.abs(drone))
eerie = (np.sin(2 * np.pi * 880 * t) + np.sin(2 * np.pi * 932.33 * t) + 0.6 * np.sin(2 * np.pi * 1318.5 * t)) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.19 * t))
denv = np.ones(N) * ramp(N, 0.0, 0.3)
denv *= 1 - ramp(N, tTRI - 0.4, tTRI + 1.2)                  # drone gives way to the major pad
denv[int(START['s1'] * SR):int(START['v1'] * SR)] *= 0.55       # "He did not stay": it opens up
denv = lp(denv, 6, 1)
L = np.zeros(N); R = np.zeros(N)
put(L, drone * denv, 0, 0.30); put(R, np.roll(drone, 331) * denv, 0, 0.30)
put(L, eerie * denv, 0, 0.014); put(R, np.roll(eerie, 977) * denv, 0, 0.014)


def boom(amp=1.0, dur=0.9, f0=95, f1=34):
    n = int(dur * SR); tt = T(n); f = f1 + (f0 - f1) * np.exp(-tt * 9)
    x = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 4.2)
    c = lp(rng.normal(0, 1, n), 1800) * np.exp(-tt * 38) * 0.6
    return fade((x + c) * amp, 0.002, 0.08)


def thump(amp):
    n = int(0.3 * SR); tt = T(n); f = 38 + 22 * np.exp(-tt * 30)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 15) * amp


hits = np.zeros(N)
for t0, a in [(0.03, 0.75), (wt('hook', 5) + LEAD, 0.95), (tTRI + LEAD, 1.15)]:
    put(hits, boom(a), t0)
# heartbeat: lub-dub under act I, dies at "He did not stay", faint ghost under the verse
tb = 0.5
while tb < START['s2'] - 0.2:
    a = 0.55 if tb < START['s1'] else 0.30 * (1 - (tb - START['v1']) / max(START['s2'] - START['v1'], 1)) if tb > START['v1'] else 0.0
    if a > 0.01:
        put(hits, thump(a), tb); put(hits, thump(a * 0.6), tb + 0.23)
    tb += 0.92 if tb < START['s1'] else 1.05
L += hits * 0.50; R += hits * 0.50

# ---------------- riser into the turn ----------------
nr = int((tTRI - START['s2'] + 0.1) * SR); tr = T(nr)
noise = lp(rng.normal(0, 1, nr), 3500, 2) * (tr / tr[-1]) ** 2.2
sweep = np.sin(2 * np.pi * np.cumsum(180 + 900 * (tr / tr[-1]) ** 2) / SR) * (tr / tr[-1]) ** 2.5
riser = fade(noise * 0.35 + sweep * 0.30, 0.2, 0.01)
put(L, riser, START['s2'] - 0.05, 0.26); put(R, np.roll(riser, 211), START['s2'] - 0.05, 0.26)

# ---------------- major pad (dawn) ----------------
def pad_note(f, n, det=0.0):
    tt = T(n); x = np.zeros(n)
    for h, a in [(1, 1.0), (2, 0.5), (3, 0.25), (4, 0.12)]:
        x += a * np.sin(2 * np.pi * f * h * (1 + det) * tt + rng.uniform(0, 6.28))
    return x


notes = [110.0, 164.81, 220.0, 277.18, 329.63, 440.0]
padL = sum(pad_note(f, N, 0.0006) * g for f, g in zip(notes, [1.0, 0.8, 0.7, 0.45, 0.45, 0.25]))
padR = sum(pad_note(f, N, -0.0006) * g for f, g in zip(notes, [1.0, 0.8, 0.7, 0.45, 0.45, 0.25]))
padL = lp(padL, 1400, 2); padR = lp(padR, 1400, 2)
pm = max(np.max(np.abs(padL)), np.max(np.abs(padR))); padL /= pm; padR /= pm
penv = ramp(N, tTRI - 0.5, tTRI + 2.2) * (0.9 + 0.1 * np.sin(2 * np.pi * 0.11 * t))
penv *= 1 - ramp(N, END - 1.6, END - 0.05)
# the pad swells for the verse and the closing ask
penv *= 0.85 + 0.15 * ramp(N, START['s3'], START['v3'] + 2.0)
L += padL * penv * 0.29; R += padR * penv * 0.29
# shimmer
sh = (np.sin(2 * np.pi * 1760 * t) + 0.7 * np.sin(2 * np.pi * 2217.5 * t) + 0.5 * np.sin(2 * np.pi * 2637 * t)) * (0.5 + 0.5 * np.sin(2 * np.pi * 0.23 * t + 1.0))
shenv = ramp(N, tTRI, tTRI + 2.5) * (1 - ramp(N, END - 1.6, END - 0.05))
L += sh * shenv * 0.012; R += np.roll(sh, 1301) * shenv * 0.012
# bright bell on "keys" and on "Type amen"
def bell(f, dur=2.6):
    n = int(dur * SR); tt = T(n)
    return (np.sin(2 * np.pi * f * tt) + 0.4 * np.sin(2 * np.pi * f * 2.01 * tt)) * np.exp(-tt * 1.8)
for t0, f, g in [(wt('s3', 6), 880.0, 0.10), (wt('close', 14), 659.26, 0.10), (wt('close', 16), 880.0, 0.12)]:
    b = bell(f); put(L, b, t0, g); put(R, b, t0 + 0.012, g)

# ---------------- mix ----------------
# Starhead B (Nov 27): voice was only 0-5 dB over the music in the turn and the Revelation close; drop the bed ~5 dB there
mwin = np.ones(N)
for w0, w1 in [(tTRI - 3.4, START['s3']), (lend('v3') - 3.6, START['close'])]:
    mwin *= 1 - 0.50 * (ramp(N, w0, w0 + 0.5) - ramp(N, w1 - 0.1, w1 + 0.5))
bedL = L * duck * mwin; bedR = R * duck * mwin
mixL = vo * 1.0 + bedL * 0.95; mixR = vo * 1.0 + bedR * 0.95
pk = max(np.max(np.abs(mixL)), np.max(np.abs(mixR)))
out = np.stack([mixL, mixR], 1) * (0.93 / pk)
sf.write('mix.wav', out.astype(np.float32), SR)
print('mix', round(len(out) / SR, 2), 's')
