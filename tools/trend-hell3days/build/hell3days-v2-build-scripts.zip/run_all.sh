set -e
cd /tmp/work/build
python3 align.py > align.log 2>&1
python3 -c "
import json;A=json.load(open('align.json'))
print({k:len(v['heard']) for k,v in A.items()})
from common import START,TOTAL;print(START,TOTAL)" > start.log 2>&1
python3 build_video.py full > render.log 2>&1
python3 audio.py > audio.log 2>&1
ffmpeg -y -loglevel error -i frames.mp4 -i mix.wav -map 0:v -map 1:a -c:v libx264 -crf 23 -preset medium -maxrate 7M -bufsize 14M -pix_fmt yuv420p -r 30 -af "loudnorm=I=-14:TP=-1.8:LRA=11" -c:a aac -b:a 160k -ar 48000 -shortest -movflags +faststart final.mp4
ffmpeg -y -loglevel error -i final.mp4 -vn -ac 1 -ar 16000 heard.wav
echo DONE > run_all.done
