import json, sys, numpy as np, soundfile as sf
from kokoro_onnx import Kokoro
k=Kokoro("models/kokoro-v1.0.onnx","models/voices-v1.0.bin")
# sounds fixes (phonemes, never respelling): liveth = LIV-eth, not LYVE-th
FIX={'lˈaɪvθ':'lˈɪvɪθ','kəlˈɔsiənz':'kəlˈɑːʃənz','ðaɪn hˈoʊli':'ðˈaɪn hˈoʊli','fˈɪftiːn':'fɪftˈiːn'}
L=json.load(open('lines.json'))
only=sys.argv[1:]
for l in L:
    if only and l['id'] not in only: continue
    ph=k.tokenizer.phonemize(l['say'],'en-us')
    for a,b in FIX.items():
        if a in ph: print('  fix',l['id'],a,'->',b); ph=ph.replace(a,b)
    a,sr=k.create(ph,voice='am_michael',speed=float(l.get('speed',1.0)),lang='en-us',is_phonemes=True)
    sf.write(f"vo_{l['id']}.wav",a.astype(np.float32),sr); print(l['id'],round(len(a)/sr,2),sr,'|',ph[:90])
