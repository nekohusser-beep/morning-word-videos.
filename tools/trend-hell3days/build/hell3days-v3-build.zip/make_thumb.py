import sys, math
sys.path.insert(0, '/tmp/work/build')
from common import ANTON
import numpy as np, cv2
from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageChops

W, H = 1280, 720
def cover(path, cx=0.5, cy=0.5, z=1.0):
    im = Image.open(path).convert('RGB'); iw, ih = im.size
    s = max(W / iw, H / ih) * z
    im = im.resize((int(iw * s), int(ih * s)), Image.LANCZOS)
    x0 = int(min(max(cx * im.width - W / 2, 0), im.width - W)); y0 = int(min(max(cy * im.height - H / 2, 0), im.height - H))
    return im.crop((x0, y0, x0 + W, y0 + H))

bg = cover('/tmp/work/v3/pandemonium.jpg', 0.62, 0.62, 1.0)
a = np.asarray(bg).astype(np.float32)
a = (a - 128) * 1.25 + 128; a[..., 0] *= 1.10; a[..., 2] *= 0.75
# darken left + top for the title, glow right
yy, xx = np.mgrid[0:H, 0:W].astype(np.float32)
dark = np.clip(0.50 + 0.50 * (xx / W), 0.3, 1.0)[..., None]
a = a * dark * 0.95
# red heat from bottom
heat = np.clip((yy / H - 0.45) * 1.6, 0, 1)[..., None]
a += heat * np.array([120, 24, 4], np.float32) * 0.6
bg = Image.fromarray(np.clip(a, 0, 255).astype(np.uint8))

def key_layer(size=900):
    L = Image.new('L', (size, size), 0); d = ImageDraw.Draw(L)
    cx = int(size * 0.22); cy = size // 2
    R = int(size * 0.17); r = int(size * 0.075)
    d.ellipse((cx - R, cy - R, cx + R, cy + R), fill=255)            # bow
    d.ellipse((cx - r, cy - r, cx + r, cy + r), fill=0)
    sh_t = int(size * 0.045)
    d.rectangle((cx + R - 10, cy - sh_t, int(size * 0.93), cy + sh_t), fill=255)   # shaft
    bx = int(size * 0.93)
    d.rectangle((bx - int(size * 0.20), cy, bx, cy + int(size * 0.17)), fill=255)  # bit
    for k in range(3):                                                                  # teeth notches
        x = bx - int(size * 0.18) + k * int(size * 0.062)
        d.rectangle((x, cy + int(size * 0.095), x + int(size * 0.028), cy + int(size * 0.17) + 2), fill=0)
    d.ellipse((cx - R - 14, cy - int(size * 0.02), cx - R + 22, cy + int(size * 0.02)), fill=0)
    # collar ring on shaft
    d.rectangle((cx + R + int(size * 0.07), cy - sh_t - 14, cx + R + int(size * 0.105), cy + sh_t + 14), fill=255)
    return L

def gold(mask):
    w, h = mask.size
    g = np.zeros((h, w, 3), np.float32)
    t = np.linspace(0, 1, h)[:, None]
    top = np.array([255, 243, 176], np.float32); mid = np.array([240, 176, 48], np.float32); low = np.array([140, 84, 10], np.float32)
    col = np.where(t < 0.5, top + (mid - top) * (t / 0.5), mid + (low - mid) * ((t - 0.5) / 0.5))
    g[:] = col[:, None, :]
    m = np.asarray(mask.filter(ImageFilter.GaussianBlur(7))).astype(np.float32) / 255.0
    gy, gx = np.gradient(m)
    shade = np.clip(-(gx + gy) * 60.0, -0.6, 0.6)[..., None]
    g = np.clip(g * (1 + shade * 0.9), 0, 255)
    img = Image.fromarray(g.astype(np.uint8)); rgba = img.convert('RGBA'); rgba.putalpha(mask); return rgba

def place(canvas, key_rgba, angle, cx, cy, scale):
    k = key_rgba.rotate(angle, expand=True, resample=Image.BICUBIC)
    k = k.resize((int(k.width * scale), int(k.height * scale)), Image.LANCZOS)
    # glow
    glow = Image.new('RGBA', canvas.size, (0, 0, 0, 0)); gk = Image.new('RGBA', k.size, (255, 190, 70, 255)); gk.putalpha(k.split()[3])
    glow.paste(gk, (int(cx - k.width / 2), int(cy - k.height / 2)), gk); glow = glow.filter(ImageFilter.GaussianBlur(26))
    canvas.alpha_composite(glow)
    sh = Image.new('RGBA', canvas.size, (0, 0, 0, 0)); sk = Image.new('RGBA', k.size, (0, 0, 0, 255)); sk.putalpha(k.split()[3].point(lambda v: int(v * 0.65)))
    sh.paste(sk, (int(cx - k.width / 2) + 10, int(cy - k.height / 2) + 14), sk); sh = sh.filter(ImageFilter.GaussianBlur(8)); canvas.alpha_composite(sh)
    canvas.alpha_composite(k, (int(cx - k.width / 2), int(cy - k.height / 2)))

canvas = bg.convert('RGBA')
# light rays behind the keys
ray = Image.new('RGBA', (W, H), (0, 0, 0, 0)); rd = ImageDraw.Draw(ray)
for i in range(14):
    ang = math.radians(-70 + i * 10); x0, y0 = 1030, 320
    rd.polygon([(x0, y0), (x0 + 1500 * math.cos(ang) - 40, y0 + 1500 * math.sin(ang)), (x0 + 1500 * math.cos(ang) + 40, y0 + 1500 * math.sin(ang))], fill=(255, 214, 120, 26))
ray = ray.filter(ImageFilter.GaussianBlur(10)); canvas.alpha_composite(ray)

kg = gold(key_layer())
place(canvas, kg, 40, 1000, 330, 0.62)
place(canvas, kg, -28, 1040, 300, 0.62)

d = ImageDraw.Draw(canvas)
def text_stroke(xy, s, size, fill, stroke, sw, anchor='la'):
    f = ImageFont.truetype(ANTON, size)
    d.text(xy, s, font=f, fill=fill, stroke_width=sw, stroke_fill=stroke, anchor=anchor)
# HELL
f_h = ImageFont.truetype(ANTON, 360)
sh = Image.new('RGBA', (W, H), (0, 0, 0, 0)); sd = ImageDraw.Draw(sh)
sd.text((60, 70), 'HELL', font=f_h, fill=(0, 0, 0, 255), stroke_width=14, stroke_fill=(0, 0, 0, 255))
sh = sh.filter(ImageFilter.GaussianBlur(14)); canvas.alpha_composite(sh)
d = ImageDraw.Draw(canvas)
d.text((52, 56), 'HELL', font=f_h, fill=(255, 255, 255, 255), stroke_width=10, stroke_fill=(190, 20, 10, 255))
text_stroke((64, 450), '3 DAYS?', 200, (255, 214, 96), (0, 0, 0), 11)
out = canvas.convert('RGB')
out.save('/tmp/work/thumb/thumb_A.jpg', quality=92)
print('ok')
